#Extract the data of the Shanghai Typhoon Research Institute line by line from the txt and write it into Excel according to the "year_typhoon name"

import os
import pandas as pd

year_name_number = {
    'year': [],
    'ename': [],
    'number': []}
nameless_count=0
for yearr in range(1949,2021):
    print(yearr)
    path = "...\CMABSTdata\\"
    year=str(yearr)
    f = open(path+"CH"+year+"BST.txt")
    line = f.readline()
    line_number=0
    title_line = line.split()
    TC_name = title_line[7]
    while line:
        judge = line.find("66666")
        if judge!=-1:
            # At this time, the line of the title of the line
            title_line=line.split()
            TC_name=title_line[7]
            if TC_name.find("nameless")!=-1:
                nameless_count=nameless_count+1
                TC_name="nameless"+str(nameless_count)
            TC_information = {
                'ename': TC_name,
                'dateUTC': [],
                'power': [],
                'lat': [],
                'long': [],
                'pres': [],
                'owd': []}
            count = 0
            line_number=0
            line_number_all=title_line[2]
        else:
            line_number=line_number+1
            content_line=line.split()
            TC_information['dateUTC'].append(content_line[0])
            TC_information['power'].append(content_line[1])
            TC_information['lat'].append(content_line[2])
            TC_information['long'].append(content_line[3])
            TC_information['pres'].append(content_line[4])
            TC_information['owd'].append(content_line[5])
            if(line_number==int(line_number_all)):
                folder = os.getcwd()[:-4] + '\\' + 'CMABSTdata' + "\\data\\" + str(year)
                if not os.path.exists(folder):
                    os.makedirs(folder)
                path = folder + '\\' + TC_name + '.xlsx'
                writer = pd.ExcelWriter(path)
                TC_information = pd.DataFrame(TC_information)
                TC_information.to_excel(writer)
                writer.save()
                writer.close()
                # Record the year_name_number of records of each typhoon
                year_name_number['year'].append(year)
                year_name_number['ename'].append(TC_name)
                year_name_number['number'].append(line_number_all)
        line = f.readline()
    f.close()
#Write it into Excel according to the year_typhoon name_number of records
folder = os.getcwd()[:-4] + '\\' + 'CMABSTdata'
if not os.path.exists(folder):
    os.makedirs(folder)
path = folder + '\\' + "year_TC_recordnumber" + '.xlsx'
writer = pd.ExcelWriter(path)
year_name_number = pd.DataFrame(year_name_number)
year_name_number.to_excel(writer)
writer.save()
writer.close()