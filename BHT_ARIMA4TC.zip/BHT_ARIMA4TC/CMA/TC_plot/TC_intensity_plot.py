# according to the input typhoon, draw the average value of n predictions for each point
# If the predicted pressure is np.load("TC_pressure.npy"), the predicted wind speed is changed to np.load("TC_wind.npy")
# The number in TC_number_list is the number of the typhoon to be drawn, this number is the row number of the typhoon in TC_wind

import numpy as np
import matplotlib.pyplot as plt
from keras import metrics
from BHT_ARIMA import BHTARIMA
from BHT_ARIMA.util.utility import get_index
from pandas import Series
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import pearsonr

def tcplot(run_number,x,TC_number):
    ori_ts = np.load('TC_pressure.npy')
    print("shape of data: {}".format(ori_ts.shape))
    print("This dataset have {} series, and each serie have {} time step".format(
        ori_ts.shape[0], ori_ts.shape[1]
    ))
    # parameters setting 6-12 5——11 4-10 3-9
    tucker_ranks=3
    number=9
    rmse_mean_list=[]
    mae_mean_list=[]
    pccs_mean_list=[]

    TC_intensity_mean = []
    TC_intensity_origin=[]
    for s in range(40-number-x):
        TC_intensity_mean.append(0)
        TC_intensity_origin.append(0)
    for r in range(run_number):
        print(r)
        rmse_list = []
        mae_list = []
        pccs_list=[]
        for i in range(40-number-x):
            left=i
            right=i+number
            ts = ori_ts[..., left:right] # training data
            ts2 = ts.copy()
            ts2[:, 0:8] = ts[:, 1:9]
            ts3 = ts.copy()
            ts3[:, 0:7] = ts[:, 1:8]
            ts4 = ts.copy()
            ts4[:, 0:6] = ts[:, 1:7]

            label = ori_ts[..., right+x] # label, take the last time step as label
            p = 3 # p-order
            d = 2 # d-order
            q = 1 # q-order
            taus = [ori_ts.shape[0], tucker_ranks] # MDT-rank
            Rs = [tucker_ranks,tucker_ranks] # tucker decomposition ranks
            k =  10 # iterations
            tol = 0.001 # stop criterion
            Us_mode = tucker_ranks # orthogonality mode

            model = BHTARIMA(ts, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
            result, _ = model.run()
            pred = result[..., -1]

            if(x == 1):

                # Use the predicted 6h value plus the known first 8 moments to predict 12h
                ts2[..., -1] = pred
                model = BHTARIMA(ts2, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

            elif (x == 2):
                # Use the predicted 6h value plus the known first 8 moments to predict 12h
                ts2[..., -1] = pred
                ts3[..., -2] = pred
                model = BHTARIMA(ts2, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

                # Use the predicted 6/12h value plus the known first 7 moments to predict 18h
                ts3[..., -1] = pred
                model = BHTARIMA(ts3, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

            elif (x == 3):
                # Use the predicted 6h value plus the known first 8 moments to predict 12h
                ts2[..., -1] = pred
                ts3[..., -2] = pred
                ts4[..., -3] = pred
                model = BHTARIMA(ts2, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

                # Use the predicted 6/12h value plus the known first 7 moments to predict 18h
                ts3[..., -1] = pred
                ts4[..., -2] = pred
                model = BHTARIMA(ts3, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

                # Use the predicted 6/12/18h value plus the known first 6 moments to predict 24h
                ts4[..., -1] = pred
                model = BHTARIMA(ts4, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
                result, _ = model.run()
                pred = result[..., -1]

            TC_intensity_mean[i]=TC_intensity_mean[i]+pred[TC_number-1]
            TC_intensity_origin[i]=label[TC_number-1]
            rmse_list.append(np.sqrt(metrics.mean_squared_error(pred, label)))
            mae_list.append(mean_absolute_error(pred,label))
            pccs_list.append(pearsonr(pred, label))
        rmse_list=np.array(rmse_list)
        rmse_mean_list.append(rmse_list.mean())
        mae_list=np.array(mae_list)
        mae_mean_list.append(mae_list.mean())
        pccs_list=np.array(pccs_list)
        pccs_mean_list.append(pccs_list.mean())

    #Calculate the floating range of n runs
    rmse_avg_number=np.array(rmse_mean_list).mean()
    rmse_std_number=np.array(rmse_mean_list).std()
    mae_avg_number=np.array(mae_mean_list).mean()
    mae_std_number=np.array(mae_mean_list).std()
    pccs_avg_number=np.array(pccs_mean_list).mean()
    pccs_std_number=np.array(pccs_mean_list).std()
    print("rmse")
    print("%f±%f"%(rmse_avg_number,rmse_std_number))
    print("mae")
    print("%f±%f"%(mae_avg_number,mae_std_number))
    print("pccs")
    print("%f±%f"%(pccs_avg_number,pccs_std_number))
    return TC_intensity_mean,TC_intensity_origin

if __name__ == "__main__":

    #Select the typhoon number to be drawn (the number of rows in "TC_wind.xlsx")
    TC_number_list = [65,511]
    TC_number_count=-1
    # plot
    number = 9
    # Set the number of runs
    run_number = 1
    for TC_number in TC_number_list:
        TC_number_count=TC_number_count+1
        TC_intensity_6_mean, TC_intensity_6_origin = tcplot(run_number,0,TC_number)
        print(TC_intensity_6_mean)
        TC_intensity_12_mean, TC_intensity_12_origin = tcplot(run_number,1,TC_number)
        print(TC_intensity_12_mean)
        TC_intensity_18_mean, TC_intensity_24_origin = tcplot(run_number,2,TC_number)
        # TC_intensity_24_mean, TC_intensity_24_origin = tcplot(3,TC_number,TC_number_count)

        plt.figure()
        for i in range(len(TC_intensity_6_mean)):
            TC_intensity_6_mean[i]=TC_intensity_6_mean[i]/run_number
        x1 = np.linspace(1, 40 - number, 40 - number)
        plt.plot(x1, TC_intensity_6_origin, color="black",label="Pressure_origin")
        plt.plot(x1, TC_intensity_6_mean,color="red",label="Pressure_predict_6")
        x2 = np.linspace(2, 40 - number, 40 - number-1)
        plt.plot(x2, TC_intensity_12_mean, color="green",label="Pressure_predict_12",linestyle='-.')
        x3 = np.linspace(3, 40 - number, 40 - number-2)
        plt.plot(x3, TC_intensity_18_mean, color="blue",label="Pressure_predict_18",linestyle=':')
        plt.legend()
        plt.xticks(x1)
        plt.title("Pressure predict")
        plt.ylabel("pressure")
        plt.xlabel('n')
        plt.show()