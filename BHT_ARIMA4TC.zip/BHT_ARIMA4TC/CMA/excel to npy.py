#Write the data in the extracted Excel file into npy
import xlwings as xw
import numpy as np
xb = xw.Book('...\TC_wind.xlsx')
xht = xb.sheets[0]
TC_density=xht.range('B1:AO537').value
TC_density=np.array(TC_density)
np.save('TC_wind.npy',TC_density)
