#Selected typhoons with more than 40 typhoon records from 1949 to 2020, including (nameless), a total of 526 typhoons
#More than 40 records, take the data with a large change in the middle part, and if it is an odd number, take the data that is biased towards the back

import xlwings as xw

xb = xw.Book('...\CMABSTdata\year_TC_recordnumber_40.xlsx')
xht = xb.sheets[0]
year=xht.range('A2:A538').value
ename=xht.range('B2:B538').value
numberr=xht.range('C2:C538').value
xb.close()
hb = xw.Book('...\TC_wind.xlsx')
for i in range(537):
    path = "...\CMABSTdata\data\\"+str(year[i])+"\\"+str(ename[i])+".xlsx"
    number=int(numberr[i])
    first=2
    if number>40:
        if number%2==1:
            number_left=number-40
            erfen=(number_left-1)/2
            first=erfen+3
        else:
            number_left=number-40
            erfen=number_left/2
            first=erfen+2
    last=first+39
    wb = xw.Book(path)
    wht = wb.sheets[0]
    TC_data=wht.range('H'+str(int(first))+':H'+str(int(last))).value#pressure->G wind->H
    wb.close()
    hht = hb.sheets[0]
    hht.range('A'+str(i+1)).value = ename[i]
    hht.range('B'+str(i+1)+':AO'+str(i+1)).value=TC_data






