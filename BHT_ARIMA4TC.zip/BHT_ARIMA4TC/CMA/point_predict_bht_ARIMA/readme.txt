#First determine the position of the suddenly enhanced point through windspeed, and then observe the prediction accuracy of the point
#First read the "TC_wind.xlsx" file line by line to determine whether the enhancement exceeds 55km/h (approximately 15m/s) within 24 hours
################
    #run_number represents the total number of runs of the program, and the result is taken as mean±std
    #If the predicted pressure is np.load("TC_pressure.npy"), the predicted wind speed is changed to np.load("TC_wind.npy")
#######