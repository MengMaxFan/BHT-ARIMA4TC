#First determine the position of the suddenly enhanced point through windspeed, and then observe the prediction accuracy of the point
#First read the TC_intensity file line by line to determine whether the enhancement exceeds 55km/h (approximately 15m/s) within 24 hours
#Forecast the intensity of the typhoon 12 hours after the sudden increase point
# If the predicted pressure is np.load("TC_pressure.npy"), the predicted wind speed is changed to np.load("TC_wind.npy")

import xlwings as xw
import numpy as np
import matplotlib.pyplot as plt
from keras import metrics
from BHT_ARIMA import BHTARIMA
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import pearsonr
from BHT_ARIMA.util.utility import get_index

run_number=30
xb = xw.Book('TC_wind.xlsx')
xht = xb.sheets[0]
line=[]
row=[]
for i in range(537):
    intensity=xht.range('B'+str(i+1)+':AO'+str(i+1)).value
    # print(intensity)
    for x in range(len(intensity)-4):
        #The selected point needs to be non-zero within 24 hours and increase more than 15m/s
        if intensity[x]!=0 and intensity[x+1]!=0 and intensity[x+2]!=0 and intensity[x+3]!=0 and intensity[x+4]!=0 and intensity[x+4]-intensity[x]>15 and x>8:
            line.append(str(i))
            row.append(str(x))
print(line)
print(row)
###################################################################################################################################################
ori_ts = np.load('TC_pressure.npy')
print("shape of data: {}".format(ori_ts.shape))
print("This dataset have {} series, and each serie have {} time step".format(
    ori_ts.shape[0], ori_ts.shape[1]
))
# parameters setting 6-12 5——11 4-10 3-9
tucker_ranks = 3
number = 9
rmse_mean_list=[]
mae_mean_list=[]
pccs_mean_list=[]
for r in range(run_number):
    print(r)
    pred_number=[]
    label_number = []
    rmse_mean_list = []
    for i in range(40 - number-1):
        left = i
        right = i + number
        ts = ori_ts[..., left:right]  # training data
        ts2 = ts.copy()
        ts2[:, 0:8] = ts[:, 1:9]

        label = ori_ts[..., right+1]  # label, take the last time step as label
        p = 3  # p-order
        d = 2  # d-order
        q = 1  # q-order
        taus = [ori_ts.shape[0], tucker_ranks]  # MDT-rank
        Rs = [tucker_ranks, tucker_ranks]  # tucker decomposition ranks
        k = 10  # iterations
        tol = 0.001  # stop criterion
        Us_mode = tucker_ranks  # orthogonality mode

        model = BHTARIMA(ts, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
        result, _ = model.run()
        pred = result[..., -1]

        # Use the predicted 6h value plus the known first 8 moments to predict 12h
        ts2[..., -1] = pred
        model = BHTARIMA(ts2, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
        result, _ = model.run()
        pred = result[..., -1]

        if str(right-1) in row:
            for p in range(len(row)):
                if str(right-1) == row[p]:
                    s=int(line[p])
                    pred_number.append(pred[s])
                    label_number.append(label[s])

    rmse_mean_list.append(np.sqrt(metrics.mean_squared_error(pred_number, label_number)))
    mae_mean_list.append(mean_absolute_error(pred, label))
    pccs_mean_list.append(pearsonr(pred, label))

#Calculate the floating range of n runs
rmse_avg_number=np.array(rmse_mean_list).mean()
rmse_std_number=np.array(rmse_mean_list).std()
mae_avg_number=np.array(mae_mean_list).mean()
mae_std_number=np.array(mae_mean_list).std()
pccs_avg_number=np.array(pccs_mean_list).mean()
pccs_std_number=np.array(pccs_mean_list).std()
print("rmse")
print("%f±%f" % (rmse_avg_number, rmse_std_number))
print("mae")
print("%f±%f" % (mae_avg_number, mae_std_number))
print("r")
print("%f±%f" % (pccs_avg_number, pccs_std_number))




