#Forecast 12-hour typhoon intensity
# If the predicted pressure is np.load("TC_pressure.npy"), the predicted wind speed is changed to np.load("TC_wind.npy")

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from BHT_ARIMA import BHTARIMA
from scipy.stats import pearsonr
from BHT_ARIMA.util.utility import get_index
from pandas import Series
if __name__ == "__main__":
    # prepare data
    ori_ts = np.load('TC_pressure.npy')
    print("shape of data: {}".format(ori_ts.shape))
    print("This dataset have {} series, and each serie have {} time step".format(
        ori_ts.shape[0], ori_ts.shape[1]
    ))
    #Set the number of runs
    run_number = 30
    # parameters setting 6-12 5——11 4-10 3-9
    tucker_ranks=3
    number=9
    rmse_mean_list=[]
    mae_mean_list=[]
    r2score_mean_list=[]
    pccs_mean_list=[]
    rmse_plot=[]
    for i in range(40 - number):
        rmse_plot.append(0)
    for r in range(run_number):
        print(r)
        rmse_list = []
        mae_list=[]
        pccs_list=[]
        for i in range(40-number-1):
            left=i
            right=i+number
            ts = ori_ts[..., left:right] # training data
            ts2 = ts.copy()
            ts2[:, 0:8] = ts[:, 1:9]
            label = ori_ts[..., right+1] # label, take the last time step as label
            p = 3 # p-order
            d = 2 # d-order
            q = 1 # q-order
            taus = [ori_ts.shape[0], tucker_ranks] # MDT-rank
            Rs = [tucker_ranks,tucker_ranks] # tucker decomposition ranks
            k =  10 # iterations
            tol = 0.001 # stop criterion
            Us_mode = tucker_ranks # orthogonality mode

            # Run program
            model = BHTARIMA(ts, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
            result, _ = model.run()
            pred = result[..., -1]

            # Use the predicted 6h value plus the known first 8 moments to predict 12h
            ts2[..., -1] = pred
            model = BHTARIMA(ts2, p, d, q, taus, Rs, k, tol, verbose=0, Us_mode=Us_mode)
            result, _ = model.run()
            pred = result[..., -1]

            rmse_list.append(np.sqrt(mean_squared_error(pred, label)))
            mae_list.append(mean_absolute_error(pred, label))
            pccs_list.append(pearsonr(pred, label))
            rmse_plot[i]=rmse_plot[i]+np.sqrt(mean_squared_error(pred, label))
        rmse_list=np.array(rmse_list)
        rmse_mean_list.append(rmse_list.mean())
        mae_list=np.array(mae_list)
        mae_mean_list.append(mae_list.mean())
        pccs_list=np.array(pccs_list)
        pccs_mean_list.append(pccs_list.mean())

    #Calculate the floating range of 100 runs
    rmse_avg_number=np.array(rmse_mean_list).mean()
    rmse_std_number=np.array(rmse_mean_list).std()
    mae_avg_number=np.array(mae_mean_list).mean()
    mae_std_number=np.array(mae_mean_list).std()
    pccs_avg_number=np.array(pccs_mean_list).mean()
    pccs_std_number=np.array(pccs_mean_list).std()
    print("rmse")
    print("%f±%f"%(rmse_avg_number,rmse_std_number))
    print("mae")
    print("%f±%f"%(mae_avg_number,mae_std_number))
    print("r")
    print("%f±%f"%(pccs_avg_number,pccs_std_number))



